console.log('Hello World!');


function myfunction() {
  // body...
//alert("this is page");
 var t=  setTimeout("showcase()",2000);
 
}
function showcase(){
  document.getElementById("showcase").style.display='none'
}
