console.log('Hello World!');
let fetch = document.getElementById('fetch')
;
fetch.addEventListener('click',clickbtn);
function clickbtn() {
  // body...
  console.log('you success full clicked');
  const xhr = new XMLHttpRequest();
  xhr.open('Get','/toin.txt',true);
  xhr.onload = function(){
    console.log(this.responseText);
  }
  xhr.onreadystatechange = function () {
         console.log('ready state is ', xhr.readyState);
        
     }
  xhr.send();
  console.log('your done');
}


/*console.log('Hello World!');
let fetch = document.getElementById('fetch')
;
fetch.addEventListener('click',clickbtn);
function clickbtn() {
  // body...
  console.log('you success full clicked');
  const xhr = new XMLHttpRequest();
  xhr.open('Get','/toumin.html',true);
  xhr.onload = function(){
    document.write(this.responseText);
  }
  xhr.onreadystatechange = function () {
         console.log('ready state is ', xhr.readyState);
        
     }
  xhr.send();
  console.log('your done');
}
*/
