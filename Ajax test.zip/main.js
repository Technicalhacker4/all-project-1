console.log('Hello World!');
/*function Myfunction() {
  var myVar;
  myVar = setTimeout(showPage, 2000);
}

/*function showPage(){
    document.getElementById('fetch').style.display = "none";
}
xhr = new XMLHttpRequest();
xhr.open('Get', '/ajax.html', true);
xhr.onreadystatechange = function () {
       if(this.readystate == 4 && this.status==200){
         document.getElementById('fetch').innerHTML = this.responseText;
       }
        
     }
     xhr.send();*/
