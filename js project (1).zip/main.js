console.log('Hello World!');
function addNewWeField(){
  // body...
 console.log("addnew field");
let newNode = document.createElement('textarea');
newNode.classList.add('form-control');
newNode.classList.add('wefield');
newNode.classList.add('mt-2');
newNode.setAttribute('row' , 3);
newNode.setAttribute('placeholder' , 'Enter here');
let weOb = document.getElementsByid("we");
let weAddButtonOb = document.getElementsByid('weAddButton');
weOb.insertBefore(newNode, weAddButtonOb);

  
};
function addNewAQfield() {
  // body...
  let newNode = document.createElement('textarea');
newNode.classList.add('form-control');
newNode.classList.add('eqfield');
newNode.classList.add('mt-2');
newNode.setAttribute('row' , 3);
newNode.setAttribute('placeholder' , 'Enter here');
let aqOb = document.getElementById('aq');
let aqAddButtonOb = document.getElementsByid('aqAddButton');
 aqOb.insertBefore(newNode, aqAddButtonOb);
};
