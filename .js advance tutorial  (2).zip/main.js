//import { log } from './logger'

//log('Import works!')
/*let ht = document.documentElement;
let he = document.head;
let bo = document.body;
console.log(ht);
console.log(he);

const setAtt = ()=> {
  let urlob   = document.getElementById('url');
  urlob.setAttribute("href" , "https://www.yahoo.com");
}*/