console.log('Hello World!');
function myfunction() {
  var myVar;
  myVar = setTimeout(showPage, 5000);
  
}
function showPage() {
  document.getElementById("fetch").style.display = "none";
  location.replace('http://localhost:7700/asmr.html');
}
