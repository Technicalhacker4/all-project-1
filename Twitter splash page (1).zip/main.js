console.log('Hello World!');


function myfunction() {
  // body...
//alert("this is page");
 var t=  setTimeout("splash()",2000);
 
}
function splash(){
  document.getElementById("splash").style.display='none';
}
