console.log('Hello World!');
  
   //a = 7;
   //b = 9;
   
 /* Artthmatic operator 
 console.log("a + b = ",a+b);
  console.log("a - b = ",a-b);
  console.log("a / b = ",a/b);
  console.log("a * b = ",a*b);*/
  /* string 
a = "harry";
b = 'coder';
console.log(b);
console.log(a);
arr = ["harry", "rohan", "sam"]
console.log(typeof(arr));
console.log(arr.length);
console.log(arr.slice(1,4));*/
/* if condition
 a = 26;
if(a<18){
  console.log("you are kid");
}else if(a<26){
  console.log("you are young");
}else{
  console.log("your able to drive car");
}
*/
/* loop
var arr = [1, 2, 3, 4, 5, 6, 7];
 console.log(arr);
 for(var i=0;i<arr.length;i++){
     if(i==2){
         break;
       // continue;
}
 console.log(arr[i])
 }

arr.forEach(function(element){
     console.log(element);
 })
 
let j = 0;
 while(j<arr.length){
     console.log(arr[j]);
     j ++;
 }

 do{
     console.log(arr[j]);
     j++;
 } while (j < arr.length);
 let mydate = new date();
  console.log(myDate.getTime());
  console.log(myDate.getFullYear());
  console.log(myDate.getDay());
  console.log(myDate.getMinutes());
 console.log(myDate.getHours());
 
 var x = 'harty';
 var newfor ='code';
 var _newsee ='see';
 var $newa ='two';*/
 /* loop
 while loop
 do/while loop
 for loop
 for in loop
 for each loop
 */
 /* while loop 
 a = 1 ;
 
 while (a<=10){
   //increment
   document.write( a + ")  toumin bano <br>");
   a = a+1;
   
 }
*/
/*do / while loop
//do means continue and while means when //condition true and false any one 
var a = 1;
do{
  // statement 
  document.write( a + ")  toumin bano <br>");
  //increment 
  //a = a+1;
  a++;
}while(a<=10)

*/
/* for loop 
// in increament do not use ";" this symbols in last 
for(a = 1; a<=10; a++) 
{
  document.write( a + ")  toumin bano <br>");
}
*/
/*for in loop 
var obj =  {
  firstname : "toumin",
  lastname : "bano",
  age : 14
};
for ( var key in obj){
  document.write( key + " : " + obj[key] + "<br>");
  
}*/
/* for each loop 
var a = ["harry", "coder", "toumin", "bano"];
a.forEach(loop);
function loop (value, index){
  document.write(index + ":" + value + "<br>");
   
}*/
// function with parameter

/*function sum(a,b){
  document.write(a+b);
}
sum(12,23);*/
// function returns 

/*function sum(a,b) {
  // code execute --
 
  return a*b;
}
var b = sum(4,6);
document.write(b);
*/
// global variables waise varible jo functions ke bhar bhi aur andar bhi run kar sakhta hai and wahi local variable kewal function ke andar hi runckiya jaa sakhta hai 
// arrow function 
//1 method 
/*sum = ()=> {
  console.log("good morning");
}
sum();
//2 method 
sum = ()=>   console.log("good morning");

sum();*/
// arrow function sum
//sum = (a,b)=> a+b;

//document.write(sum(12,23));
// switch case 
/*var day = 8;
switch (day) {
  case 1:
    // code execute
    document.write("Monday");
    break;
  case 2:
    // code execute
    document.write("Tuesday");
    break;
    case 3:
      // code execute
      document.write("Wednesday");
    break;
    case 4:
      // code execute
      document.write("Thursday");
    break;
    case 5:
      // code execute
      document.write("Friday");
    break;
    case 6:
      // code execute
      document.write("Saturday");
    break;
     case 7:
      // code execute
      document.write("Sunday");
    break;
    
    default:
    document.write("Number are valid");
}*/
/* age switch case 
var age =34;
switch (true) {
    case (age==18):
    // code
    document.write("you are elder");
    break;
    
    case (age<18):
    // code
    document.write("you are child");
    break;
    
    case (age>35)://this symbol greater than
    
    // code
    document.write("you are old");
    break;
    
    case (age<=35):
    // code
    document.write("you are baby");
    break;
    
    case (age>=18):
    // code
    document.write("you are mature");
    break;
    
}*/
// multiple line case write 
/*var day = 7;
switch (day) {
  case 1: case 2: case 3: 
    // code execute
    document.write("Monday");
    break;

    case 4:
      // code execute
      document.write("Thursday");
    break;
    case 5:
      // code execute
      document.write("Friday");
    break;
    case 6:
      // code execute
      document.write("Saturday");
    break;
     case 7:
      // code execute
      document.write("Sunday");
    break;
    
    default:
    document.write("Number are valid");
}*/
//dom
//var tittle = document.getElementById("body");
//console.log(tittle);
//tittle.innerText = "pro "
//tittle.innerHTML ="computer professional";
//var classes = document.getElementsByClassName("page main");
//console.log(classes);
/*function myfunction(){
document.getElementById("click").setAttribute("class","democlass" );
}*/
//dom style 

 var header = document.querySelector("#header");
 header.style.fontsize='larger';
//header.style.paddingright ='80%';
//document.querySelectorAll("#header")[0];
header.style.color ='black';
header.style.background ='purple'
header.style.width = '20%';
document.getElementById('header').style.marginLeft = "40%";

//header.innerHTML= 'hello';
//header.innerText= 'how are you';
// event 
// wrong

//click.onclick = clicknow;
//click.onclick= function(){
  //alert("thank");
//}s
//document.getElementById('click');
//click.addEventListener("click" ,clicknow);
// event right
  /*function clicknow(){
    body.style.background ='red';
  }
  // clickbtn = addEventListener(click);
 clickbtn = addEventListener("click" , clicknow);
*/
//date object utc
const d = new Date();
 document.getElementById('imo').innerHTML= d.getFullYear();
 const h = new Date();
 document.getElementById('h').innerHTML= h.getHours();
 
 const m = new Date();
 document.getElementById('m').innerHTML= m.getMinutes();
 const s = new Date();
 document.getElementById('s').innerHTML= s.getSeconds();
 const ml = new Date();
 document.getElementById('ml').innerHTML= ml.getMilliseconds();
 
 /*
let h = getMinutes();
document.getElementById('h').innerHTML= h.getMinutes();
let m = getSeconds();
let s = getMilliseconds();
let ml = getHours();
console.log(h,m,s,ml);
/*document.getElementById('h').innerHTML= 
h.getHours();
document.getElementById('m').innerHTML= 
m.getMinutes();
document.getElementById('s').innerHTML = 
s.getSeconds();
  document.getElementById('ml').innerHTML = ml.getMilliseconds();*/
// set interval
setInterval(displayHello, 1000);
function displayHello() {
  document.getElementById("dem").innerHTML += "Hello";
}

function displayHello() {
  clearInterval(setInterval);
}
// set timeout
const myTimeout = setTimeout(myGreeting, 5000);

function myGreeting() {
  document.getElementById("de").innerHTML = "Happy Birthday!"
}
const myInterval = setInterval(myTimer, 1000);
function myTimer() {
  const date = new Date();
  document.getElementById("deo").innerHTML = date.toLocaleTimeString();
}
// clear interval
function myStop() {
  clearInterval(myInterval);
}