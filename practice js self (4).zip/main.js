console.log('Hello World!');
  
   //a = 7;
   //b = 9;
   
 /* Artthmatic operator 
 console.log("a + b = ",a+b);
  console.log("a - b = ",a-b);
  console.log("a / b = ",a/b);
  console.log("a * b = ",a*b);*/
  /* string 
a = "harry";
b = 'coder';
console.log(b);
console.log(a);
arr = ["harry", "rohan", "sam"]
console.log(typeof(arr));
console.log(arr.length);
console.log(arr.slice(1,4));*/
/* if condition
 a = 26;
if(a<18){
  console.log("you are kid");
}else if(a<26){
  console.log("you are young");
}else{
  console.log("your able to drive car");
}
*/
/* loop
var arr = [1, 2, 3, 4, 5, 6, 7];
 console.log(arr);
 for(var i=0;i<arr.length;i++){
     if(i==2){
         break;
       // continue;
}
 console.log(arr[i])
 }

arr.forEach(function(element){
     console.log(element);
 })
 
let j = 0;
 while(j<arr.length){
     console.log(arr[j]);
     j ++;
 }

 do{
     console.log(arr[j]);
     j++;
 } while (j < arr.length);
 let mydate = new date();
  console.log(myDate.getTime());
  console.log(myDate.getFullYear());
  console.log(myDate.getDay());
  console.log(myDate.getMinutes());
 console.log(myDate.getHours());
 
 var x = 'harty';
 var newfor ='code';
 var _newsee ='see';
 var $newa ='two';*/
 /* loop
 while loop
 do/while loop
 for loop
 for in loop
 for each loop
 */
 /* while loop 
 a = 1 ;
 
 while (a<=10){
   //increment
   document.write( a + ")  toumin bano <br>");
   a = a+1;
   
 }
*/
/*do / while loop
//do means continue and while means when //condition true and false any one 
var a = 1;
do{
  // statement 
  document.write( a + ")  toumin bano <br>");
  //increment 
  //a = a+1;
  a++;
}while(a<=10)

*/
/* for loop 
// in increament do not use ";" this symbols in last 
for(a = 1; a<=10; a++) 
{
  document.write( a + ")  toumin bano <br>");
}
*/
/*for in loop 
var obj =  {
  firstname : "toumin",
  lastname : "bano",
  age : 14
};
for ( var key in obj){
  document.write( key + " : " + obj[key] + "<br>");
  
}*/
/* for each loop 
var a = ["harry", "coder", "toumin", "bano"];
a.forEach(loop);
function loop (value, index){
  document.write(index + ":" + value + "<br>");
   
}*/
// function with parameter

/*function sum(a,b){
  document.write(a+b);
}
sum(12,23);*/
// function returns 

/*function sum(a,b) {
  // code execute --
 
  return a*b;
}
var b = sum(4,6);
document.write(b);
*/
// global variables waise varible jo functions ke bhar bhi aur andar bhi run kar sakhta hai and wahi local variable kewal function ke andar hi runckiya jaa sakhta hai 
// arrow function 
//1 method 
/*sum = ()=> {
  console.log("good morning");
}
sum();
//2 method 
sum = ()=>   console.log("good morning");

sum();*/
// arrow function sum
//sum = (a,b)=> a+b;

//document.write(sum(12,23));
// switch case 
/*var day = 8;
switch (day) {
  case 1:
    // code execute
    document.write("Monday");
    break;
  case 2:
    // code execute
    document.write("Tuesday");
    break;
    case 3:
      // code execute
      document.write("Wednesday");
    break;
    case 4:
      // code execute
      document.write("Thursday");
    break;
    case 5:
      // code execute
      document.write("Friday");
    break;
    case 6:
      // code execute
      document.write("Saturday");
    break;
     case 7:
      // code execute
      document.write("Sunday");
    break;
    
    default:
    document.write("Number are valid");
}*/
/* age switch case 
var age =34;
switch (true) {
    case (age==18):
    // code
    document.write("you are elder");
    break;
    
    case (age<18):
    // code
    document.write("you are child");
    break;
    
    case (age>35)://this symbol greater than
    
    // code
    document.write("you are old");
    break;
    
    case (age<=35):
    // code
    document.write("you are baby");
    break;
    
    case (age>=18):
    // code
    document.write("you are mature");
    break;
    
}*/
// multiple line case write 
/*var day = 7;
switch (day) {
  case 1: case 2: case 3: 
    // code execute
    document.write("Monday");
    break;

    case 4:
      // code execute
      document.write("Thursday");
    break;
    case 5:
      // code execute
      document.write("Friday");
    break;
    case 6:
      // code execute
      document.write("Saturday");
    break;
     case 7:
      // code execute
      document.write("Sunday");
    break;
    
    default:
    document.write("Number are valid");
}*/
//dom
//var tittle = document.getElementById("body");
//console.log(tittle);
//tittle.innerText = "pro "
//tittle.innerHTML ="computer professional";
//var classes = document.getElementsByClassName("page main");
//console.log(classes);
/*function myfunction(){
document.getElementById("click").setAttribute("class","democlass" );
}*/
//dom style 
/*
 var header = document.querySelector("#header");
 header.style.fontsize='larger';
//header.style.paddingright ='80%';
//document.querySelectorAll("#header")[0];
header.style.color ='black';
header.style.background ='purple'
header.style.width = '20%';
document.getElementById('header').style.marginLeft = "40%";

*/
// toaday 16 October


//header.innerHTML= 'hello';
//header.innerText= 'how are you';
// event 
// wrong

//click.onclick = clicknow;
//click.onclick= function(){
  //alert("thank");
//}s
//document.getElementById('click');
//click.addEventListener("click" ,clicknow);
// event right
/*
  function clicknow(){
    body.style.background ='red';
  }
  // clickbtn = addEventListener(click);
 clickbtn = addEventListener("click" , clicknow);

//date object utc
const d = new Date();
 document.getElementById('imo').innerHTML= d.getFullYear();
 const h = new Date();
 document.getElementById('h').innerHTML= h.getHours();
 
 const m = new Date();
 document.getElementById('m').innerHTML= m.getMinutes();
 const s = new Date();
 document.getElementById('s').innerHTML= s.getSeconds();
 const ml = new Date();
 document.getElementById('ml').innerHTML= ml.getMilliseconds();
 
 /*
let h = getMinutes();
document.getElementById('h').innerHTML= h.getMinutes();
let m = getSeconds();
let s = getMilliseconds();
let ml = getHours();
console.log(h,m,s,ml);
/*document.getElementById('h').innerHTML= 
h.getHours();
document.getElementById('m').innerHTML= 
m.getMinutes();
document.getElementById('s').innerHTML = 
s.getSeconds();
  document.getElementById('ml').innerHTML = ml.getMilliseconds();
// set interval
setInterval(displayHello, 1000);
function displayHello() {
  document.getElementById("dem").innerHTML += "Hello";
}

function displayHello() {
  clearInterval(setInterval);
}
// set timeout
const myTimeout = setTimeout(myGreeting, 5000);

function myGreeting() {
  document.getElementById("de").innerHTML = "Happy Birthday!"
}
const myInterval = setInterval(myTimer, 1000);
function myTimer() {
  const date = new Date();
  document.getElementById("deo").innerHTML = date.toLocaleTimeString();
}
// clear interval
function myStop() {
  clearInterval(myInterval);
}
//array
/*
const fruits = ["Banana", "Orange", "Apple"];
fruits.push("Lemon"); 
const fruits = ["Banana", "Orange", "Apple"];
fruits[fruits.length] = "Lemon";  // Adds "Lemon" to fruits
const fruits = ["Banana", "Orange", "Apple"];
fruits[6] = "Lemon";  // Creates undefined "holes" in fruits
const fruits = ["Banana", "Orange", "Apple"];
let type = typeof fruits;
const fruits = ["Banana", "Orange", "Apple"];
fruits instanceof Array;*/
/* practice 
function change(){
  let tittle = document.getElementById('BTS');
  tittle.innerText= 'off';
}
clickyou = addEventListener('BTS' , change);

/* project- s21 

function mystart(){
    body.style.background ='red';
  }
  clickbtn = addEventListener("btn1" , mystart);

function mystop(){
  body.style.background ='white';
}
clickbtn1 = addEventListener("btn2" , mystop);*/
/* project-s22
 myInterval = setInterval(setColor, 500);
function setColor() {
  let x = document.body;
 x.style.backgroundColor = x.style.backgroundColor == "yellow" ? "pink" : "yellow";
}
function stopcolor() {
  clearInterval(myInterval);
}*/
/* project-s23

function myon(){
  let tittle = document.getElementById('btn1');
  tittle.innerText= 'on';
  let bulb = document.getElementById('img');
 bulb.src='/img/pic_bulbon.gif';
}
clickyou = addEventListener('btn1' , myon);
/* practice*/
//createdElement = document.createElement('div');
//createdElement.innerText = "This is a created para";
//console.log(createdElement);
 /*var  a = 2;
 function myfunction(){
   if (a>1) {
      document.write('2 × 1 = ' + a*1  + '<br>');
      document.write('2 × 2 = ' + a*2  + '<br>');
      document.write('2 × 3 = ' + a*3  + '<br>');
      document.write('2 × 4 = ' + a*4  + '<br>');
      document.write('2 × 5 = ' + a*5  + '<br>');
      document.write('2 × 6 = ' + a*6  + '<br>');
      document.write('2 × 7 = ' + a*7  + '<br>');
      document.write('2 × 8 = ' + a*8  + '<br>');
      document.write('2 × 9 = ' + a*9  + '<br>');
      document.write('2 × 10 = ' + a*10 + '<br>');
     
   }
   else{
     document.write('connect to network');
   }
 }
 myfunction();
 
var  a = 2;
 function myfunction(){
   if (a>1) {
      document.write('2 × 1 = ' + a*1  + '<br>');
      document.write('2 × 2 = ' + a*2  + '<br>');
      document.write('2 × 3 = ' + a*3  + '<br>');
      document.write('2 × 4 = ' + a*4  + '<br>');
      document.write('2 × 5 = ' + a*5  + '<br>');
      document.write('2 × 6 = ' + a*6  + '<br>');
      document.write('2 × 7 = ' + a*7  + '<br>');
      document.write('2 × 8 = ' + a*8  + '<br>');
      document.write('2 × 9 = ' + a*9  + '<br>');
      document.write('2 × 10 = ' + a*10 + '<br>');
     
   }
   else{
     document.write('connect to network');
   }
 }
 myfunction();*/
 // Math object
 // ceil method nearest value 88 output 89 67.78 so output 68
 /*
 var a = Math.ceil(88.56);
 document.write(a);
 // math floor nearest when number negative 
 var b = Math.floor(-89.56 );
 document.write(b);
 
 var c = Math.round(89.-56);
 document.write(c);
 
 var d = Math.trunc(89.-56);
 document.write(d);
 
 // max means maximum 
 
 var e = Math.max(89,65,232,21);
 document.write(e);
 */
 //min means minimum 
 /*var f = Math.min(89,35,46,45,65);
 document.write(f);
 
/* 
// sqrt means square root

 var g = Math.sqrt(4);
 document.write(g);
 
 // cube root
 
var h = Math.cbrt(9);
 document.write(h);
 
 
 // pow means power of number find 
 
/* var i = Math.pow(3,3);
 document.write(i);*/
 
 /*var j = Math.floor= (Math.random()*10 +1);
 document.write(j);*/
 

 // abs means absolute value of numbere
 
/* var k = Math.abs(856);
 document.write(k);*/
 

 
//var L = Math.PI();
//document.write(L);
/*a = 34;
 var a = Math.pI;
 document.write(a);
 
 */
 // object map
 /*
 console.log("This is tutorial 57");

// Maps in JavaScript: We can use any type of key or value
const myMap = new Map();

const key1 = 'myStr', key2 = {}, key3 = function () { };

// Setting map values
myMap.set(key1, 'This is a string');
myMap.set(key2, 'This is a blank obj');
myMap.set(key3, 'This is an empty function');
console.log(myMap);

// Getting the values from a Map 
let value1 = myMap.get(key3);
console.log(value1);

// Get the size of the map
console.log(myMap.size);

// You can loop using for..of to get keys and values
for (let [key, value] of myMap) {
    console.log(key, value);
}

// Get only keys
for (let key of myMap.keys()) {
    console.log('key is ', key);
}
// Get only values
for (let value of myMap.values()) {
    console.log('value is ', value);
}

// You can loop through a map using for each loop
myMap.forEach((value, key)=>{
    console.log('Key is ', key);
    console.log('Value is ', value);
})

// Converting map to an array
let myArray = Array.from(myMap);
console.log('Map to array is ', myArray);

// Converting map keys to an array
let myKeysArray = Array.from(myMap.keys());
console.log('Map to keys array is ', myKeysArray);

// Converting map values to an array
let myValuesArray = Array.from(myMap.values());
console.log('Map to values array is ', myValuesArray);
*/
 //set object
 /*
 console.log('This is tutorial 58');
 
 // Set stores unique values
 const mySet = new Set(); // Initialize an empty set
 console.log('The set looks like :', mySet);
 
 // Adding values to this set
 mySet.add('this');
 mySet.add('My name');
 mySet.add('this');
 mySet.add('that');
 mySet.add(34);
 mySet.add(true);
 mySet.add(false);
 mySet.add('that2');
 console.log('The set looks like this now:', mySet);
 
 // Use a constructor to initialize the set
 let mySet2 = new Set([1, 45, 'this', false, { a: 4, b: 8 }, 'this']);
 console.log('New set:', mySet2);
 
 
 console.log(mySet.size); // Get the size of the set
 
 console.log(mySet.has(346)); // Check whether set has 346 or not
 
 console.log('Before removal', mySet.has('that2'));
 mySet.delete('that2'); // Remove an element from the set
 console.log('After removal', mySet.has('that2'));
 
 
 // Iterating a set
 // for(let item of mySet){
 //     console.log('Item is  :', item );
 // }
 
 mySet.forEach((item) => {
   console.log('Item is  :', item);
 })
 
 // Quiz: Can you use Array.from(mySet) to convert set into an array?
 */
 // symbol
 console.log("This is tutorial 59")

// Symbols
const sym1 =  Symbol('My identifier');
const sym2 =  Symbol('My identifier');
// console.log('Symbol is ', sym1);
// console.log('Type of Symbol is ', typeof sym1);
console.log(sym1 === sym2);

const a = "this is";
const b = "this is";

console.log(a === b);
console.log(null === null);
console.log(undefined === undefined);

const k1 = Symbol('identifier for k1');
const k2 = Symbol('for k2');

myObj = {};
myObj[k1] = "Harry";
myObj[k2] = "Rohan";
myObj["name"] = "Good boy"
myObj[4] = "Good int"


console.log(myObj);
console.log(myObj[k1]);
console.log(myObj[k2]);
console.log(myObj.k2); // !! ALERT !!: cannot do this to get Rohan because it is same as myObj["k2"]


// Symbols are ignored in for in loop
for(key in myObj){
    console.log(key, myObj[key])
}

console.log(JSON.stringify(myObj));
