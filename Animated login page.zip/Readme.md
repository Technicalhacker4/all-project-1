```
```

## Login page styled with 
## HTML & CSS

## Contact: Discord: JS#2061

## info

/script ~ script alert() login

/css ~ all CSS styles

/login ~ "Login" html page

/contact ~ "contact" html page

/creadc ~ "create account" html page

/index.html ~ Default page

icons ~ https://www.flaticon.com ~
## ~~ for educational use. 2022

```
```

## Página de Login estilizada com
## HTML & CSS

## Contato: Discord: JS#2061

## infos
/script ~ script alert()-login

/css ~ todos os estilos CSS

/login ~ Página html "Login"

/contato ~ Página html "contato"

/creadc ~ Página html "criar conta"

/index.html ~ Página padrão

icons ~ https://www.flaticon.com ~
## ~~ for educational use. 2022