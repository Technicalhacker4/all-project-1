function clic() {
  alert("Pronto você tá logado de mentirinha :)")
}