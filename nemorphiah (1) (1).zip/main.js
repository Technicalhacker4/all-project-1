/*console.log('Hello World!');
$(window).on('load', function() {

        $('#js-preloader').addClass('loaded');

    });

	

function mobileNav() {
    var width = $(window).width();
    $('.submenu').on('click', function() {
      if(width < 767) {
        $('.submenu ul').removeClass('active');
        $(this).find('ul').toggleClass('active');
      }
    });
  }




})(window.jQuery);

let list = document.querySelectorAll("li");
let nav = document.querySelector("nav");
    
    
 list.forEach((element) => {
   element.addEventListener("click",function(e){
     list.forEach((el) => {
       el.classList.remove("active");
     });
     
     elements.classList.add("active");
     nav.style.setProperty("--left",element.offsetLeft + "px");
   });
 });*/
 
